const data = [
    {
        "ddt": "2024-06-30T10:20:13.007",
        "id": 40175,
        "q4_1": "The Astana air transfer desk in Istanbul was very very unprofessional and lacks knowledge of basic procedures . Mr Suleyman Evevin also the manager Mr Volkan who was very rude at the departure desk . Unfortunately Mr Volkan was very rude ",
        "lan": "EN"
    },
    {
        "ddt": "2024-06-30T09:57:33.227",
        "id": 40174,
        "q4_1": "Не задерживать свои рейсы ,из за задержки ваших рейсов я опоздала на встречу :",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T11:12:12.397",
        "id": 40177,
        "q4_1": "Безопасность полета! Необходимо тщательнее отбирать пилотов!",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T11:14:09.16",
        "id": 40179,
        "q4_1": "Рейс задержка 5 часов, отстой!",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T11:14:53.477",
        "id": 40180,
        "q4_1": "One flight attendant on flight 853 - she was tall and large - was very rude to me and to other customers. Perhaps training for her could be reinforced that clients are the raison detre of an airline.",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T12:02:10.547",
        "id": 40187,
        "q4_1": "Keep your airplanes in good technical condition.",
        "lan": "EN"
    },
    {
        "ddt": "2024-06-30T00:22:38.33",
        "id": 40162,
        "q4_1": "Рейсы меняются переодически   Не регулируют очередь на посадку   Нет беруш , даже в бизнес классе   Нет четкой работы персонала , расхалажено",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T01:21:46.693",
        "id": 40164,
        "q4_1": "It was very uncomfortable flight because of many raesons, but actually Air Astana had changed time of flight more than 3 times per day and finally we flew from Almaty on the Fly Arystans plane. Without any apologies and compensations from your ",
        "lan": "EN"
    },
    {
        "ddt": "2024-06-30T07:29:32.397",
        "id": 40171,
        "q4_1": "There is no business class lounge at the airport ",
        "lan": "EN"
    },
    {
        "ddt": "2024-06-30T13:32:50.59",
        "id": 40192,
        "q4_1": "Непонятное необьясненное расписание, задержка была с 2 до 6:40 вылетели в 7:30",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T13:43:06.893",
        "id": 40194,
        "q4_1": "Staff was not friendly - had to ask for water multiple time before being served",
        "lan": "EN"
    },
    {
        "ddt": "2024-06-30T22:04:36.577",
        "id": 40214,
        "q4_1": "Время ",
        "lan": "KZ"
    },
    {
        "ddt": "2024-06-30T13:14:28.03",
        "id": 40191,
        "q4_1": "Аэропорт Алматы и 2 стойки регистрации совершенно не приспособлены к такому количеству людей. Мой рейс объединили с туркишами. Мне дали новое место, хотя у меня было забронировано у окна и вероятно мест было продано больше, чем есть, так как мне",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T15:08:05.25",
        "id": 40197,
        "q4_1": "Очень напряженные стюардессы, хамили, были грубы. За все годы впервые. ",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T15:09:14.867",
        "id": 40198,
        "q4_1": "Опоздание на 8 часов без каких-либо причин - значит, следует проверить ответственный департамент. Не мне вас учить",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T15:55:44.683",
        "id": 40201,
        "q4_1": "На международном 6 часовом рейсе у одного места есть 90 фильмов, а у кого-то всего 9 фильмов в наличие. На вопрос что это и как быть, стюардессы отвечают: «ну вот так вот, такая система». Почините свою систему.",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T19:57:03.047",
        "id": 40208,
        "q4_1": "Have enough blankets for every customers! I have asked for a blanket but the attendant said that they all dustributed so I had to feel cold  for  six hours kn the plane.🙁",
        "lan": "EN"
    },
    {
        "ddt": "2024-06-30T19:57:48.07",
        "id": 40209,
        "q4_1": "У супруга телевизор не работал весь полет не могли настроет. Тапочек не дают. С каждым разом сервис падает. В косметических наборах не было ложки для обуви. ",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T21:16:41.833",
        "id": 40211,
        "q4_1": "Do not lose baggage and please make sure Almaty airport release baby trolly at the gate like all over the world airports do..",
        "lan": "EN"
    },
    {
        "ddt": "2024-06-30T21:29:23.74",
        "id": 40212,
        "q4_1": "Избегать задержек рейсов более чем на 6 часов",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T21:39:09.87",
        "id": 40213,
        "q4_1": "Второй мой рейс за неделю задержан. Неисправен разъем для на ушников мультимедийной системы на месте 38K",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T22:22:32.173",
        "id": 40217,
        "q4_1": "Рейс вылетел с опозданием. На рейсе не было предоставлено питание. Бортпроводники разъяснили, что службы аэропорта надлежащим образом не обеспечили рейс.",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T22:50:34.53",
        "id": 40220,
        "q4_1": "Стюардесса разлила кипяток, не извинилась. Далее было очень холодно, не дали плед. ",
        "lan": "RU"
    },
    {
        "ddt": "2024-06-30T23:37:56.627",
        "id": 40221,
        "q4_1": "Сюардессаларыңызды әдептілікке үйретуді сұраймын. Тамақты таратқанда өте дөрекілік көресетті. Сіздер оларды қинап жұмысқа салып отырсыздар ма? «Говорите громко» деген қалай сонда😬. Солай сөйлеуге болама пассажирге? ",
        "lan": "KZ"
    }
]

export default data;